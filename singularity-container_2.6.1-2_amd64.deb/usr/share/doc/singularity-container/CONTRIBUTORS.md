#Project Lead:

    - Gregory M. Kurtzer <gmkurtzer@gmail.com>

#Developers:

    - Cedric Clerget <cedric.clerget@univ-fcomte.fr>
    - Dave Dykstra <dwd@fnal.gov>
    - Dave Godlove <davidgodlove@gmail.com>
    - David Trudgian <david.trudgian@utsouthwestern.edu>
    - Eduardo Arango <carlos.arango.gutierrez@correounivalle.edu.co>
    - Krishna Muriki <kmuriki@lbl.gov>
    - Michael Bauer <bauerm@umich.edu>
    - Vanessa Sochat <vsochat@stanford.edu>
    - Yannick Cote <yhcote@gmail.com>

#Contributors:

    - Afif Elghraoui <afif.elghraoui@nih.gov>
    - Amanda Duffy <aduffy@lenovo.com>
    - Ángel Bejarano <abejarano@ontropos.com>
    - Bernard Li <bernardli@lbl.gov>
    - Brian Bockelman <bbockelm@cse.unl.edu>
    - Chris Hollowell <hollowec@bnl.gov>
    - Christian Neyers <foss@neyers.org>
    - Daniele Tamino <daniele.tamino@gmail.com>
    - Dave Love <d.love@liverpool.ac.uk>
    - Diana Langenbach <dcl@dcl.sh>
    - Felix Abecassis <fabecassis@nvidia.com>
    - George Hartzell <hartzell@alerce.com>
    - Hakon Enger <hakonenger@github.com>
    - Hugo Meiland <hugo.meiland@microsoft.com>
    - Jarrod Johnson <jjohnson2@lenovo.com>
    - Jason Stover <jason.stover@gmail.com>
    - Jeff Kriske <jekriske@gmail.com>
    - Josef Hrabal <josef.hrabal@vsb.cz>
    - Justin Riley <justin_riley@harvard.edu>
    - Maciej Sieczka <msieczka@sieczka.org>
    - Mark Egan-Fuller <markeganfuller@googlemail.com>
    - Michael Herzberg <michael@mherzberg.de>
    - Nathan Lin <nathan.lin@yale.edu>
    - Oleksandr Moskalenko <om@rc.ufl.edu>
    - Oliver Freyermuth <freyermuth@physik.uni-bonn.de>
    - Peter Steinbach <steinbach@scionics.de>
    - Petr Votava <votava.petr@gene.com>
    - Rafal Gumienny <rafal.gumienny@gmail.com>
    - Ralph Castain <rhc@open-mpi.org>
    - Rémy Dernat <remy.dernat@umontpellier.fr>
    - Richard Neuboeck <hawk@tbi.univie.ac.at>
    - Tarcisio Fedrizzi <tarcisio.fedrizzi@gmail.com>
    - Thomas Hamel <hmlth@t-hamel.fr>
    - Yaroslav Halchenko <debian@onerussian.com>
    - Matt Wiens <mwiens91@gmail.com>
    - Marcin Stolarek <stolarek.marcin@gmail.com>
